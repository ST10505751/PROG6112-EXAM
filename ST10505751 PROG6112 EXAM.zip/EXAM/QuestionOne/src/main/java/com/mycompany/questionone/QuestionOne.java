/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.questionone;
import javax.swing.*;
import java.awt.*;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author Student
 */
public class QuestionOne {
public interface IProductSales {

    int getTotalSales();

    double getAverageSales();

    int getProductTotal(int productIndex);

    String getMostPopularProduct();
}
public class ProductSales implements IProductSales {

    // Store the names of the three mattress products
    private String[] products = {
        "Single Mattress",
        "Double Mattress",
        "Queen Mattress"
    };

    // Store sales for three products over three months
    private int[][] sales = {
        {120, 150, 130},
        {180, 200, 220},
        {250, 270, 300}
    };

    // Calculate the total sales of all products
    @Override
    public int getTotalSales() {
        int total = 0;

        for (int i = 0; i < sales.length; i++) {
            for (int j = 0; j < sales[i].length; j++) {
                total += sales[i][j];
            }
        }

        return total;
    }

    // Calculate the average sales per product
    @Override
    public double getAverageSales() {
        return (double) getTotalSales() / products.length;
    }

    // Calculate the total sales for an individual product
    @Override
    public int getProductTotal(int productIndex) {
        int total = 0;

        for (int j = 0; j < sales[productIndex].length; j++) {
            total += sales[productIndex][j];
        }

        return total;
    }

    // Identify the most popular product
    @Override
    public String getMostPopularProduct() {
        int highestSales = 0;
        int popularIndex = 0;

        for (int i = 0; i < products.length; i++) {

            int productTotal = getProductTotal(i);

            if (productTotal > highestSales) {
                highestSales = productTotal;
                popularIndex = i;
            }
        }

        return products[popularIndex];
    }

    // Display the complete sales report
    public void displayReport() {

        System.out.println("==============================================");
        System.out.println("       MATTRESS COMPANY SALES REPORT");
        System.out.println("==============================================");

        System.out.printf("%-20s %8s %8s %8s %10s%n",
                "Product", "Month 1", "Month 2",
                "Month 3", "Total");

        System.out.println("----------------------------------------------");

        for (int i = 0; i < products.length; i++) {

            System.out.printf("%-20s %8d %8d %8d %10d%n",
                    products[i],
                    sales[i][0],
                    sales[i][1],
                    sales[i][2],
                    getProductTotal(i));
        }

        System.out.println("----------------------------------------------");

        System.out.println("Total Products Sold: " + getTotalSales());

        System.out.printf("Average Sales Per Product: %.2f%n",
                getAverageSales());

        System.out.println("Most Popular Product: "
                + getMostPopularProduct());

        System.out.println("==============================================");
    }
}

public class MattressSalesReport {

    public static void main(String[] args) {

        // Create an object of the ProductSales class
        ProductSales report = new ProductSales();

        // Display the mattress sales report
        report.displayReport();
    }
}

public interface IProduct {

    int GetTotalProductsSold();

    double GetAverageProductSold();

    String GetMostPopularProduct();
}

public class Product implements IProduct {

    // Single-dimensional array containing product names
    private String[] productNames = {
        "Cozy Nights Monarch",
        "Restonic Barbados",
        "Sealy Phuket"
    };

    // Two-dimensional array containing monthly sales
    private int[][] productSales = {
        {120, 150, 130},
        {180, 200, 220},
        {250, 270, 300}
    };

    // Calculate total products sold
    @Override
    public int GetTotalProductsSold() {

        int total = 0;

        for (int i = 0; i < productSales.length; i++) {

            for (int j = 0; j < productSales[i].length; j++) {

                total += productSales[i][j];
            }
        }

        return total;
    }

    // Calculate average products sold per product
    @Override
    public double GetAverageProductSold() {

        return (double) GetTotalProductsSold()
                / productNames.length;
    }

    // Determine the most popular product
    @Override
    public String GetMostPopularProduct() {

        int highestSales = 0;
        int popularProduct = 0;

        for (int i = 0; i < productSales.length; i++) {

            int productTotal = 0;

            for (int j = 0; j < productSales[i].length; j++) {

                productTotal += productSales[i][j];
            }

            if (productTotal > highestSales) {

                highestSales = productTotal;
                popularProduct = i;
            }
        }

        return productNames[popularProduct];
    }

    // Get product names
    public String[] GetProductNames() {
        return productNames;
    }

    // Get monthly sales data
    public int[][] GetProductSales() {
        return productSales;
    }

    // Calculate individual product total
    public int GetProductTotal(int index) {

        int total = 0;

        for (int j = 0; j < productSales[index].length; j++) {

            total += productSales[index][j];
        }

        return total;
    }
}

public class PrintProduct {

    private Product product;

    // Constructor
    public PrintProduct(Product product) {
        this.product = product;
    }

    // Print total product sales
    public void PrintTotalProductSales() {

        System.out.println("Total Products Sold: "
                + product.GetTotalProductsSold());
    }

    // Print average product sales
    public void PrintAverageProductSales() {

        System.out.printf("Average Products Sold: %.2f%n",
                product.GetAverageProductSold());
    }

    // Print most popular product
    public void PrintMostPopularProductSales() {

        System.out.println("Most Popular Product: "
                + product.GetMostPopularProduct());
    }

    // Print complete sales report
    public void PrintReport() {

        String[] names = product.GetProductNames();
        int[][] sales = product.GetProductSales();

        System.out.println("==============================================");
        System.out.println("          MATTRESS PRODUCT SALES REPORT");
        System.out.println("==============================================");

        System.out.printf("%-22s %8s %8s %8s %8s%n",
                "Product", "Month 1", "Month 2",
                "Month 3", "Total");

        System.out.println("----------------------------------------------");

        for (int i = 0; i < names.length; i++) {

            System.out.printf("%-22s %8d %8d %8d %8d%n",
                    names[i],
                    sales[i][0],
                    sales[i][1],
                    sales[i][2],
                    product.GetProductTotal(i));
        }

        System.out.println("----------------------------------------------");

        PrintTotalProductSales();

        PrintAverageProductSales();

        PrintMostPopularProductSales();

        System.out.println("==============================================");
    }
}

public class MattressSalesReport {

    public static void main(String[] args) {

        // Create Product object
        Product product = new Product();

        // Create PrintProduct object
        PrintProduct report = new PrintProduct(product);

        // Display the sales report
        report.PrintReport();
    }
}
}
