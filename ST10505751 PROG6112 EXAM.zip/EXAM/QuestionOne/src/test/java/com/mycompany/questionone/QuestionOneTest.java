/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.questionone;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Student
 */
public class QuestionOneTest {
    
    public QuestionOneTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }
}
public class ProductTest {

    Product product = new Product();

    // Test total products sold
    @Test
    public void GetTotalProductsSold_ReturnsCorrectTotal() {

        assertEquals(1820, product.GetTotalProductsSold());
    }

    // Test average products sold
    @Test
    public void GetAverageProductSold_ReturnsCorrectAverage() {

        assertEquals(606.67,
                product.GetAverageProductSold(), 0.01);
    }

    // Test most popular product
    @Test
    public void GetMostPopularProduct_ReturnsCorrectProduct() {

        assertEquals("Sealy Phuket",
                product.GetMostPopularProduct());
    }
}

