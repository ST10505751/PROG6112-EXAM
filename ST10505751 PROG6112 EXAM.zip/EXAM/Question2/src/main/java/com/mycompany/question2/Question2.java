/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.question2;
import javax.swing.*;
import java.awt.*;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author Student
 */
public class Question2 implements IProductCalculations{

    public static void main(String[] args) {
    }
    
public interface IProductCalculations {

    double GetVat();

    double GetCommission();

    double GetTotal();
}

public class ProductCalculations implements IProductCalculations {

    private double productPrice;

    // Constructor
    public ProductCalculations(double productPrice) {

        this.productPrice = productPrice;
    }

    // Calculate VAT at 15%
    @Override
    public double GetVat() {

        return productPrice * 0.15;
    }

    // Calculate commission at 5%
    @Override
    public double GetCommission() {

        return productPrice * 0.05;
    }

    // Calculate total sale amount
    @Override
    public double GetTotal() {

        return productPrice + GetVat() + GetCommission();
    }
}



public class ProductCalculations implements IProductCalculations {

    private double productPrice;

    // Constructor
    public ProductCalculations(double productPrice) {

        this.productPrice = productPrice;
    }

    // Calculate VAT at 15%
    @Override
    public double GetVat() {

        return productPrice * 0.15;
    }

    // Calculate commission at 5%
    @Override
    public double GetCommission() {

        return productPrice * 0.05;
    }

    // Calculate total sale amount
    @Override
    public double GetTotal() {

        return productPrice + GetVat() + GetCommission();
    }
}



public class MattressSalesGUI extends JFrame {

    // GUI components
    private JTextField txtCustomerName;
    private JComboBox<String> cmbProduct;
    private JTextField txtProductPrice;

    private JTextField txtVat;
    private JTextField txtCommission;
    private JTextField txtTotal;

    private JTextArea txtReport;

    private JButton btnProcess;
    private JButton btnClear;

    // Constructor
    public MattressSalesGUI() {

        setTitle("Mattress Sales Management System");

        setSize(600, 550);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLocationRelativeTo(null);

        createMenu();

        createForm();

        setVisible(true);
    }

    // Create the menu system
    private void createMenu() {

        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu("File");
        JMenu toolsMenu = new JMenu("Tools");

        JMenuItem exitItem = new JMenuItem("Exit");
        JMenuItem processItem = new JMenuItem("Process");
        JMenuItem clearItem = new JMenuItem("Clear");

        // Exit menu item
        exitItem.addActionListener(e -> System.exit(0));

        // Process menu item
        processItem.addActionListener(e -> processSale());

        // Clear menu item
        clearItem.addActionListener(e -> clearForm());

        fileMenu.add(exitItem);

        toolsMenu.add(processItem);
        toolsMenu.add(clearItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);

        setJMenuBar(menuBar);
    }

    // Create the GUI form
    private void createForm() {

        JPanel panel = new JPanel(new GridLayout(0, 2, 10, 10));

        panel.setBorder(
                BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Customer name
        panel.add(new JLabel("Customer Name:"));

        txtCustomerName = new JTextField();
        panel.add(txtCustomerName);

        // Product selection
        panel.add(new JLabel("Product Name:"));

        cmbProduct = new JComboBox<>(new String[] {
            "Cozy Nights Monarch",
            "Restonic Barbados",
            "Sealy Phuket"
        });

        panel.add(cmbProduct);

        // Product price
        panel.add(new JLabel("Product Price:"));

        txtProductPrice = new JTextField();
        panel.add(txtProductPrice);

        // VAT
        panel.add(new JLabel("VAT Amount (15%):"));

        txtVat = new JTextField();
        txtVat.setEditable(false);
        panel.add(txtVat);

        // Commission
        panel.add(new JLabel("Commission Amount (5%):"));

        txtCommission = new JTextField();
        txtCommission.setEditable(false);
        panel.add(txtCommission);

        // Total sale
        panel.add(new JLabel("Total Sale Amount:"));

        txtTotal = new JTextField();
        txtTotal.setEditable(false);
        panel.add(txtTotal);

        // Process button
        btnProcess = new JButton("Process");

        btnProcess.addActionListener(e -> processSale());

        panel.add(btnProcess);

        // Clear button
        btnClear = new JButton("Clear");

        btnClear.addActionListener(e -> clearForm());

        panel.add(btnClear);

        // Report text area
        txtReport = new JTextArea(8, 40);

        txtReport.setEditable(false);

        JScrollPane scrollPane = new JScrollPane(txtReport);

        setLayout(new BorderLayout());

        add(panel, BorderLayout.NORTH);

        add(scrollPane, BorderLayout.CENTER);
    }

    // Processing the customer sale
    private void processSale() {

        try {

            String customerName =
                    txtCustomerName.getText().trim();

            String productName =
                    (String) cmbProduct.getSelectedItem();

            // Validate customer name
            if (customerName.isEmpty()) {

                JOptionPane.showMessageDialog(
                        this, "Please enter customer name.");

                return;
            }

            // Validate product price
            String priceText = txtProductPrice.getText().trim();

            if (priceText.isEmpty()) {

                JOptionPane.showMessageDialog(
                        this, "Please enter product price.");

                return;
            }

            double price = Double.parseDouble(priceText);

            if (!Double.isFinite(price) || price <= 0) {

                JOptionPane.showMessageDialog(
                        this, "Please enter a valid positive price.");

                return;
            }

            // Create calculation object
            ProductCalculations calculation =
                    new ProductCalculations(price);

            // Perform calculations
            double vat = calculation.GetVat();

            double commission = calculation.GetCommission();

            double total = calculation.GetTotal();

            // Display calculated values
            txtVat.setText(String.format("%.2f", vat));

            txtCommission.setText(
                    String.format("%.2f", commission));

            txtTotal.setText(String.format("%.2f", total));

            // Create transaction report
            String report =
                    "CUSTOMER SALES DETAILS\n"
                    + "Customer Name: " + customerName + "\n"
                    + "Product Name: " + productName + "\n"
                    + String.format("Product Price: R%.2f%n", price)
                    + String.format("VAT Amount: R%.2f%n", vat)
                    + String.format("Commission Amount: R%.2f%n",
                            commission)
                    + String.format("Total Sale Amount: R%.2f%n",
                            total)
                    + "----------------------------------\n";

            // Display report
            txtReport.append(report);

            // Save information to data.txt
            try (PrintWriter writer =
                    new PrintWriter(
                            new FileWriter("data.txt", true))) {

                writer.print(report);
            }

            JOptionPane.showMessageDialog(
                    this, "Sale processed and saved successfully!");

        } catch (NumberFormatException ex) {

            JOptionPane.showMessageDialog(
                    this, "Please enter a valid numerical price.");

        } catch (IOException ex) {

            JOptionPane.showMessageDialog(
                    this, "Error saving data: " + ex.getMessage());
        }
    }

    // Clear all fields
    private void clearForm() {

        txtCustomerName.setText("");

        txtProductPrice.setText("");

        txtVat.setText("");

        txtCommission.setText("");

        txtTotal.setText("");

        txtReport.setText("");

        cmbProduct.setSelectedIndex(0);
    }

    // Main method
    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            new MattressSalesGUI();

        });
    }
}


private void processSale() {

    try {

        // Capture customer details
        String customerName = txtCustomerName.getText().trim();

        String productName =
                cmbProduct.getSelectedItem().toString();

        // Capture product price
        double price = Double.parseDouble(
                txtProductPrice.getText().trim());

        // Validate customer name and price
        if (customerName.isEmpty() || price <= 0
                || !Double.isFinite(price)) {

            JOptionPane.showMessageDialog(
                    this, "Enter a valid customer name and price.");

            return;
        }

        // Create ProductCalculations object
        ProductCalculations calculation =
                new ProductCalculations(price);

        // Calculate VAT, commission and total
        double vat = calculation.GetVat();

        double commission = calculation.GetCommission();

        double total = calculation.GetTotal();

        // Display calculated information
        txtVat.setText(String.format("%.2f", vat));

        txtCommission.setText(
                String.format("%.2f", commission));

        txtTotal.setText(String.format("%.2f", total));

        // Prepare sales information
        String report =
                "Customer Name: " + customerName + "\n"
                + "Product Name: " + productName + "\n"
                + String.format("Product Price: R%.2f%n", price)
                + String.format("VAT Amount: R%.2f%n", vat)
                + String.format("Commission Amount: R%.2f%n",
                        commission)
                + String.format("Total Sale Amount: R%.2f%n",
                        total)
                + "--------------------------------\n";

        // Display information
        txtReport.append(report);

        // Save information to data.txt
        try (PrintWriter writer = new PrintWriter(
                new FileWriter("data.txt", true))) {

            writer.print(report);
        }

        JOptionPane.showMessageDialog(
                this, "Sales information saved successfully!");

    } catch (NumberFormatException e) {

        JOptionPane.showMessageDialog(
                this, "Please enter a valid product price.");

    } catch (IOException e) {

        JOptionPane.showMessageDialog(
                this, "Error saving file: " + e.getMessage());
    }
}



private void createMenu() {

    // Create menu bar
    JMenuBar menuBar = new JMenuBar();

    // Create menus
    JMenu fileMenu = new JMenu("File");

    JMenu toolsMenu = new JMenu("Tools");

    // Create menu items
    JMenuItem exitItem = new JMenuItem("Exit");

    JMenuItem processItem = new JMenuItem("Process");

    JMenuItem clearItem = new JMenuItem("Clear");

    // Exit application
    exitItem.addActionListener(e -> {

        System.exit(0);

    });

    // Process sales
    processItem.addActionListener(e -> {

        processSale();

    });

    // Clear form
    clearItem.addActionListener(e -> {

        clearForm();

    });

    // Add items to menus
    fileMenu.add(exitItem);

    toolsMenu.add(processItem);

    toolsMenu.add(clearItem);

    // Add menus to menu bar
    menuBar.add(fileMenu);

    menuBar.add(toolsMenu);

    // Display menu bar
    setJMenuBar(menuBar);
}



private void clearForm() {

    // Clear customer name
    txtCustomerName.setText("");

    // Clear product price
    txtProductPrice.setText("");

    // Clear VAT
    txtVat.setText("");

    // Clear commission
    txtCommission.setText("");

    // Clear total sale amount
    txtTotal.setText("");

    // Clear report area
    txtReport.setText("");

    // Set combo box selected index to 0
    cmbProduct.setSelectedIndex(0);
}


public interface IProductCalculations {

    double GetVat();

    double GetCommission();

    double GetTotal();
}


public class ProductCalculations
        implements IProductCalculations {

    private double productPrice;

    // Constructor
    public ProductCalculations(double productPrice) {

        this.productPrice = productPrice;
    }

    // Calculate VAT at 15%
    @Override
    public double GetVat() {

        return productPrice * 0.15;
    }

    // Calculate commission at 5%
    @Override
    public double GetCommission() {

        return productPrice * 0.05;
    }

    // Calculate total sale amount
    @Override
    public double GetTotal() {

        return productPrice + GetVat() + GetCommission();
    }
}

}
