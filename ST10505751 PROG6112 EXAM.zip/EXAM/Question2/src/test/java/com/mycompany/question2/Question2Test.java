/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.question2;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Student
 */
public class Question2Test {
    
    public Question2Test() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }
    
}
public class ProductCalculationsTest {

    // Unit Test 1:
    // Test that VAT is calculated correctly
    @Test
    public void GetVat_WithValidData_ReturnsCorrectValue() {

        ProductCalculations calculation =
                new ProductCalculations(10000);

        assertEquals(1500.00,
                calculation.GetVat(), 0.01);
    }

    // Unit Test 2:
    // Test that commission is calculated correctly
    @Test
    public void GetCommission_WithValidData_ReturnsCorrectValue() {

        ProductCalculations calculation =
                new ProductCalculations(10000);

        assertEquals(500.00,
                calculation.GetCommission(), 0.01);
    }

    // Unit Test 3:
    // Test that total sale amount is calculated correctly
    @Test
    public void GetTotal_WithValidData_ReturnsCorrectValue() {

        ProductCalculations calculation =
                new ProductCalculations(10000);

        assertEquals(12000.00,
                calculation.GetTotal(), 0.01);
    }
}

